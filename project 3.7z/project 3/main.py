import math

z = int(input())
if z < 0:
    x = 2 * z + 1
else:
    x = z ** 2 - z
if x == 0:
    print("Ошибка")
else:
    x = math.log(x)
    y = math.sin(x) ** 2 + math.cos(x ** 3) ** 5 + math.log(x ** (2/5))
    m = (max(x + y + z, x * y * z))/(max(x + y + z, x / (y * z)))
    print("m =", m)
    print("x =", x)
    print("y =", y)
    print("z =", z)
